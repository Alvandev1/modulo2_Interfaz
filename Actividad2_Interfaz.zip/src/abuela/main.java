package abuela;

import javax.swing.*;

public class main {
    public static void main(String[] args) {
        // Garantiza que la interfaz se ejecute en el hilo correcto
        SwingUtilities.invokeLater(() -> {
            // Crear ventana principal
            JFrame frame = new JFrame("Gestor de usuarios");
            frame.setContentPane(new fonsify().getPanel1()); // carga el panel del .form
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.pack();       // ajusta al tamaño preferido de los componentes
            frame.setLocationRelativeTo(null); // centra en pantalla
            frame.setVisible(true); // muestra la ventana
        });


    }
}
