package abuela;

import javax.swing.*;

public class fonsify {
    private JPanel panel1;
    private JButton ajustesButton;
    private JButton menuButton;
    private JButton usuariosButton;
    private JButton informesButton;
    private JButton ayudaButton;
    private JTextField textField1;
    private JTextField textField2;
    private JComboBox comboBox1;
    private JCheckBox porFavorCheckBox;
    private JTextArea textArea1;
    private JTabbedPane tabbedPane1;
    private JTextArea textArea2;
    private JList list1;
    private JButton guardarButton;
    private JButton limpiarButton;
    private JButton cancelarButton;

    // 👉 Constructor: aquí es donde inicializas la lógica
    public fonsify() {
        guardarButton.addActionListener(e -> {
            DialogConfirmacion dialog = new DialogConfirmacion();
            dialog.setModal(true);
            dialog.pack();
            dialog.setLocationRelativeTo(null);
            dialog.setVisible(true);
        });
    }

    // 👉 Getter para acceder al panel desde fuera
    public JPanel getPanel1() {
        return panel1;
    }
}
