package abuela;

import javax.swing.*;

public class DialogConfirmacion extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JButton buttonCancel;
    private JLabel mensajeLabel;

    public DialogConfirmacion() {
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonOK);

        buttonOK.addActionListener(e -> onOK());
        buttonCancel.addActionListener(e -> onCancel());

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
    }

    private void onOK() {
        // aquí pondrás lo que pase al aceptar
        System.out.println("Guardado correctamente");
        dispose();
    }

    private void onCancel() {
        System.out.println("Se ha cancelado correctamente");
        dispose();
    }
}
